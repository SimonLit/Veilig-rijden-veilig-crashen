#ifndef SERCOM_H_
#define SERCOM_H_

void serialCommunicatie(void);

#endif 