
#include <stdio.h>
#include <string.h>
#include "sercom.h"
#include "../datastruct/datastruct.h"

#define RECEIVE_BUFFER_SIZE 50

void serialCommunicatie(void)
{
	
}